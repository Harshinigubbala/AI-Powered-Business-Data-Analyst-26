from pathlib import Path
import pandas as pd

DATA_PATH = Path("data/raw/Online Retail.xlsx")


def load_data(path=DATA_PATH):
    """Load and prepare UCI Online Retail data.

    Keep only completed sales with positive quantity and unit price.
    This removes cancellation invoices (InvoiceNo starting with C) and
    returns/invalid rows (non-positive quantity or unit price).
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}. Download Online Retail.xlsx from "
            "the UCI Online Retail dataset page and save it at this path."
        )

    df = pd.read_excel(path)
    required = {"InvoiceNo", "StockCode", "Description", "Quantity",
                "InvoiceDate", "UnitPrice", "Country"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")

    df["InvoiceDate"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce")
    df["UnitPrice"] = pd.to_numeric(df["UnitPrice"], errors="coerce")
    df = df.dropna(subset=["InvoiceDate", "Quantity", "UnitPrice", "Country"])
    df = df[
        ~df["InvoiceNo"].astype(str).str.upper().str.startswith("C")
        & (df["Quantity"] > 0)
        & (df["UnitPrice"] > 0)
    ].copy()

    df["Sales"] = df["Quantity"] * df["UnitPrice"]
    df["Year"] = df["InvoiceDate"].dt.year
    df["Month"] = df["InvoiceDate"].dt.month
    df["Year-Month"] = df["InvoiceDate"].dt.to_period("M").astype(str)
    df["Country"] = df["Country"].astype(str).str.strip()
    df["Description"] = df["Description"].fillna("Unknown product").astype(str).str.strip()
    return df


def get_business_summary(df):
    return {
        "Total Sales (£)": float(round(df["Sales"].sum(), 2)),
        "Total Quantity": int(df["Quantity"].sum()),
        "Total Invoices": int(df["InvoiceNo"].nunique()),
        "Countries": int(df["Country"].nunique()),
    }


def get_product_analysis(df):
    return df.groupby("Description", dropna=False).agg(
        Total_Sales=("Sales", "sum"),
        Total_Quantity=("Quantity", "sum"),
        Invoice_Count=("InvoiceNo", "nunique")
    ).reset_index().sort_values("Total_Sales", ascending=False)


def get_country_analysis(df):
    return df.groupby("Country").agg(
        Total_Sales=("Sales", "sum"),
        Total_Quantity=("Quantity", "sum"),
        Invoice_Count=("InvoiceNo", "nunique")
    ).reset_index().sort_values("Total_Sales", ascending=False)


def get_monthly_analysis(df):
    return df.groupby("Year-Month").agg(
        Total_Sales=("Sales", "sum"),
        Total_Quantity=("Quantity", "sum"),
        Invoice_Count=("InvoiceNo", "nunique")
    ).reset_index().sort_values("Year-Month")


if __name__ == "__main__":
    data = load_data()
    print("Prepared rows:", len(data))
    print("Business summary:", get_business_summary(data))
    print("\nTop countries by sales:")
    print(get_country_analysis(data).head(10).round(2).to_string(index=False))
