# AI-Powered Business Data Analyst

A Streamlit dashboard and rule-based natural-language question interpreter for the UCI Online Retail transaction dataset.

## Dataset source and description
- Source: [UCI Machine Learning Repository — Online Retail](https://archive.ics.uci.edu/dataset/352/online-retail)
- Dataset records transactions for a UK-based online retailer from 1 December 2010 to 9 December 2011.
- The source dataset has 541,909 transaction rows and includes invoice, product, quantity, date, unit price, customer ID, and customer country.
- Country is used as the geographic/location dimension. Sales are derived as `Quantity × UnitPrice` in GBP; the dataset does not provide a profit field.

Download `Online Retail.xlsx` from the UCI page and place it at `data/raw/Online Retail.xlsx`.

## Preparation and assumptions
The loader parses transaction dates and numeric fields, removes rows with missing required analysis values, excludes cancellation invoices (invoice number begins with `C`), and excludes non-positive quantities or unit prices. It creates sales, year, month, and year-month fields. These choices mean the dashboard reports positive completed-sales transactions; it does not report returns/cancellations or net revenue after returns. The original source contains customer identifiers; the dashboard does not display them as a metric.

## Features
- Country and year filters.
- Sales, quantity, invoice count, and country count summary.
- Sales by country, top products, and monthly sales trends.
- Rule-based questions with answers, calculation steps, and supporting tables.
- Follow-up context, clarification for underspecified grouped questions, and unsupported-topic handling.

## Technology
Python, Pandas, Streamlit, Plotly, Excel dataset.

## Project structure
```text
AI_Business_Data_Analyst/
├── data/raw/Online Retail.xlsx
├── analysis.py
├── qa_engine.py
├── dashboard.py
├── validation_report.md
└── readme.md
```

## Setup
```bash
python -m pip install -r requirements.txt
python -m streamlit run dashboard.py
```
Run from the project root. The Excel file must exist at the path above.

## Question workflow
1. Identify a supported measure: sales, quantity, or distinct invoices.
2. Identify a grouping: country, product, month, or year.
3. Identify total, highest, lowest, or breakdown intent.
4. Calculate with Pandas on the filtered data.
5. Return a plain-language answer, calculation explanation, and supporting table when applicable.
6. Ask for clarification when the requested grouped analysis is underspecified; decline out-of-scope topics.

## Validation
After placing the dataset, run:
```bash
python analysis.py
```
Then verify the dashboard totals against independently calculated Pandas sums on the same cleaned data. Independent calculation checks and Q&A tests are recorded in `validation_report.md`. Run the dashboard locally to verify the interactive charts, filters, and display.

## Limitations and misleading-answer risk
- This is historical data for one retailer, not a current or representative view of all retail businesses.
- Sales are calculated from quantity and unit price; no profit, cost, margin, or product category field is supplied.
- Cancellation and non-positive quantity/price rows are excluded by the preparation rules. This is not a net-of-returns accounting report.
- The question interpreter uses keywords and supports only documented measures/groupings; similar wording may be misunderstood.
- “Highest/lowest” answers are based on the filtered rows and the prepared data.
- Product descriptions may be inconsistent or missing in the source.

To reduce misleading answers, show the filters, explain the calculation, expose supporting results, and state the data-cleaning rules and scope.

## AI tools
AI assistance was used for coding guidance and documentation. The app itself uses a deterministic, rule-based question interpreter and does not call a generative AI service. The developer should review and be able to explain the code.

## Improvements
Add automated tests, richer intent handling, return/net-sales treatment, and optional deployment.
