import pandas as pd


MEASURES = {
    "sales": "Sales",
    "revenue": "Sales",
    "quantity": "Quantity",
    "units": "Quantity",
    "invoices": "InvoiceNo",
    "orders": "InvoiceNo",
}
GROUPS = {
    "country": "Country",
    "countries": "Country",
    "product": "Description",
    "products": "Description",
    "item": "Description",
    "items": "Description",
    "month": "Year-Month",
    "monthly": "Year-Month",
    "year": "Year",
}


def answer_question(df, question, previous_question=None):
    q = (question or "").lower().strip()
    prev = (previous_question or "").lower().strip()
    measure_key = next((k for k in MEASURES if k in q), None)
    if measure_key is None:
        measure_key = next((k for k in MEASURES if k in prev), None)

    if any(term in q for term in ("weather", "sports", "politics")):
        return _response("That topic is outside this retail dataset. Ask about sales, quantity, invoices, countries, products, or time trends.",
                         "The question is outside the supported business-data scope.")

    if measure_key is None:
        return _response("Please specify sales, quantity, or invoice/order count.",
                         "No supported measure was identified.")

    measure = MEASURES[measure_key]
    group_key = next((k for k in GROUPS if k in q), None)
    if group_key is None:
        group_key = next((k for k in GROUPS if k in prev), None)
    group_col = GROUPS.get(group_key) if group_key else None

    highest = any(x in q for x in ("highest", "maximum", "top", "most", "largest"))
    lowest = any(x in q for x in ("lowest", "minimum", "least", "smallest"))
    compare = any(x in q for x in ("compare", "comparison", "breakdown", "by "))

    # Carry the prior analysis intent into short follow-up questions such as
    # "What about quantity?" when the user changes only the measure.
    if not (highest or lowest or compare):
        highest = any(x in prev for x in ("highest", "maximum", "top", "most", "largest"))
        lowest = any(x in prev for x in ("lowest", "minimum", "least", "smallest"))
        compare = any(x in prev for x in ("compare", "comparison", "breakdown", "by "))

    if highest and lowest:
        return _response("Please ask for either the highest or the lowest result, not both.",
                         "The requested ranking contains conflicting directions.")

    if group_col:
        value_col = measure
        if measure == "InvoiceNo":
            grouped = df.groupby(group_col)[value_col].nunique().rename("Value").reset_index()
            label = "distinct invoices"
        else:
            grouped = df.groupby(group_col)[value_col].sum().rename("Value").reset_index()
            label = "total " + measure.lower()

        if highest:
            row = grouped.sort_values("Value", ascending=False).iloc[0]
            return _response(
                f"{row[group_col]} has the highest {label}: {row['Value']:,.2f}.",
                f"Grouped rows by {group_col}, calculated {label} for each group, and sorted descending.",
                grouped.sort_values("Value", ascending=False).head(10)
            )
        if lowest:
            row = grouped.sort_values("Value", ascending=True).iloc[0]
            return _response(
                f"{row[group_col]} has the lowest {label}: {row['Value']:,.2f}.",
                f"Grouped rows by {group_col}, calculated {label} for each group, and sorted ascending.",
                grouped.sort_values("Value", ascending=True).head(10)
            )
        if compare or group_key in ("month", "monthly", "year"):
            return _response(
                f"Here is the {measure.lower()} breakdown by {group_col}.",
                f"Grouped rows by {group_col} and calculated {label}.",
                grouped.sort_values("Value", ascending=False).head(20)
            )
        return _response(
            f"Would you like the highest, lowest, or a comparison of {measure.lower()} by {group_col}?",
            "A grouping was identified, but the requested analysis was not clear."
        )

    if any(x in q for x in ("total", "overall", "sum")):
        value = df[measure].nunique() if measure == "InvoiceNo" else df[measure].sum()
        label = "distinct invoices" if measure == "InvoiceNo" else measure.lower()
        return _response(f"Total {label}: {value:,.2f}.",
                         f"Calculated the {'distinct count of' if measure == 'InvoiceNo' else 'sum of'} {measure} in the filtered data.",
                         pd.DataFrame({"Metric": [f"Total {label}"], "Value": [value]}))

    return _response("Please ask for a total, highest/lowest result, or breakdown by country, product, month, or year.",
                     "The question did not specify a supported calculation.")


def _response(answer, steps, data=None):
    return {"answer": answer, "steps": steps, "data": data}
