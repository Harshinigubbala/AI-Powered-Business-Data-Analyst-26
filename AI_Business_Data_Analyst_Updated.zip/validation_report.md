# Validation Report — UCI Online Retail

Dataset used: UCI Machine Learning Repository, Online Retail (`Online Retail.xlsx`).
Preparation: 541,909 source rows; 530,104 retained rows after removing rows with missing required fields, cancellation invoices (invoice number starts with `C`), non-positive quantity, and non-positive unit price. Sales = Quantity × UnitPrice.

## Independent calculation checks

Expected values were calculated independently from the original Excel data using Pandas, then compared with the prepared-data functions and Q&A outputs.

| Test | Input | Independently calculated expected result | Application result | Status |
|---|---|---|---|---|
| 1 | Total sales | £10,666,684.544 | £10,666,684.54 | Pass |
| 2 | Total quantity | 5,588,376 | 5,588,376 | Pass |
| 3 | Total distinct invoices | 19,960 | 19,960 | Pass |
| 4 | Country with highest sales | United Kingdom — £9,025,222.084 | United Kingdom — £9,025,222.08 | Pass |
| 5 | Country with highest quantity | United Kingdom — 4,662,390 | United Kingdom — 4,662,390 | Pass |

## Question handling

| Input | Expected behavior | Observed behavior | Status |
|---|---|---|---|
| Which country has highest sales? | Return top country, value, method, and supporting table | United Kingdom; supporting country totals returned | Pass |
| Which country has highest sales? → What about quantity? | Keep country/highest intent and change measure to quantity | United Kingdom, highest quantity 4,662,390 | Pass |
| Show sales by country | Return country breakdown | Country sales breakdown returned | Pass |
| What is the weather in Hyderabad? | Decline unsupported topic and state supported scope | Unsupported-topic response returned | Pass |

## Filter check
The data loader and dashboard filter expressions were checked for country/year fields. Interactive browser testing of the Streamlit page remains to be completed in the user's local environment.

## Misleading-answer scenario and mitigation
A user might mistake sales for profit or assume returns are included. The dataset has no profit/cost field. The app explicitly defines sales as `Quantity × UnitPrice`, excludes cancellation invoices and non-positive quantity/price rows, and documents that its sales are not net of returns. It therefore does not present a profit metric.

## Test limitations
Python syntax compilation and data/Q&A calculations were checked here. The Streamlit interface itself was not launched in this environment because Streamlit is not installed here; run it locally using the setup instructions and confirm the charts, filters, and Q&A display.
